package edu.colorado.csci3155.project1

import javax.xml.crypto.dsig.SignedInfo

/* -- Here are all the instructions to be supported --*/
sealed trait StackMachineInstruction
case class  LoadI(s: String) extends StackMachineInstruction
case class  StoreI(s: String) extends StackMachineInstruction
case class  PushI(f: Double) extends StackMachineInstruction
case object AddI extends StackMachineInstruction
case object SubI extends StackMachineInstruction
case object MultI extends StackMachineInstruction
case object DivI extends StackMachineInstruction
case object ExpI extends StackMachineInstruction
case object LogI extends StackMachineInstruction
case object SinI extends StackMachineInstruction
case object CosI extends StackMachineInstruction
case object PopI extends StackMachineInstruction


object StackMachineEmulator {

    /*  Function emulateSingleInstruction
        Given   a list of doubles to represent a stack
                a map from string to double precision numbers for the environment
        and     a single instruction of type StackMachineInstruction
        Return  a tuple that contains the:
                modified stack that results when the instruction is executed.
                modified environment that results when the instruction is executed.

        Make sure you handle the error cases: eg., stack size must be appropriate for the instruction
        being executed. Division by zero, log of a non negative number
        Throw an exception or assertion violation when error happens.
    */
    def emulateSingleInstruction(stack: List[Double],
                                 env:   Map[String, Double],
                                 ins:   StackMachineInstruction): (List[Double], Map[String, Double]) = {
        // TODO: Your code here
        ins match {
            case LoadI(i) => stack match {
                case Nil => throw new IllegalArgumentException("cannot LoadI: stack empty")
                case v::tail => (tail, env + (i -> v))
            }
            case StoreI(i) =>
                if(!env.contains(i)) throw new IllegalArgumentException("cannot StoreI: identifier not found")
                (env(i)::stack, env)
            case PushI(d) => (d::stack, env)
            case PopI => stack match {
                case Nil => throw new IllegalArgumentException("Cannot PopI: empty stack")
                case _::tail => (tail, env)
            }
            case AddI => stack match {
                case Nil => throw new IllegalArgumentException("Cannot AddI: stack empty (1)")
                case v1::tail1 => tail1 match {
                    case Nil => throw new IllegalArgumentException("Cannot AddI: stack empty (2)")
                    case v2::tail2 => ((v1 + v2)::tail2, env)
                }
            }
            case SubI => stack match {
                case Nil => throw new IllegalArgumentException("Cannot SubI: stack empty (1)")
                case v1::tail1 => tail1 match {
                    case Nil => throw new IllegalArgumentException("Cannot SubI: stack empty (2)")
                    case v2::tail2 => ((v2 - v1)::tail2, env)
                }
            }
            case MultI => stack match {
                case Nil => throw new IllegalArgumentException("Cannot MultI: stack empty (1)")
                case v1::tail1 => tail1 match {
                    case Nil => throw new IllegalArgumentException("Cannot MultI: stack empty (2)")
                    case v2::tail2 => ((v1 * v2)::tail2, env)
                }
            }
            case DivI => stack match {
                case Nil => throw new IllegalArgumentException("Cannot DivI: stack empty (1)")
                case v1::tail1 => tail1 match {
                    case Nil => throw new IllegalArgumentException("Cannot DivI: stack empty (2)")
                    case v2::tail2 =>
                        if(v1 == 0) throw new IllegalArgumentException("cannot DivI: divide by zero")
                        ((v2 / v1)::tail2, env)
                }
            }
            case LogI => stack match {
                case Nil => throw new IllegalArgumentException("Cannot LogI: stack empty")
                case v::tail =>
                    if(math.log(v) < 0) throw new IllegalArgumentException("cannot LogI: result is negative")
                    (math.log(v)::tail, env)
            }
            case ExpI => stack match {
                case Nil => throw new IllegalArgumentException("Cannot ExpI: stack empty")
                case v::tail => (math.exp(v)::tail, env)
            }
            case SinI => stack match {
                case Nil => throw new IllegalArgumentException("Cannot SinI: stack empty")
                case v::tail => (math.sin(v)::tail, env)
            }
            case CosI => stack match {
                case Nil => throw new IllegalArgumentException("Cannot CosI: stack empty")
                case v::tail => (math.cos(v)::tail, env)
            }
        }
    }

    /*  Function emulateStackMachine

        Execute the list of instructions provided as inputs using the emulateSingleInstruction function.
        Use foldLeft over list of instruction rather than a for loop if you can.
        Return value must be the final environment.

        Hint:   accumulator for foldLeft must be a tuple (List[Double], Map[String,Double])
                initial value of this accumulator must be (Nil, Map.empty)
                You should use emulateSingleInstruction to update the accumulator.
                It will all fit nicely once you figure it out.
    */
    def emulateStackMachine(instructionList: List[StackMachineInstruction]): Map[String, Double] = {
        // TODO: Your code here
        val foldFunction = (acc:(List[Double], Map[String, Double]), item:StackMachineInstruction) => {
            emulateSingleInstruction(acc._1, acc._2, item)
        }
        val (_, env) = instructionList.foldLeft[ (List[Double], Map[String, Double]) ](Nil, Map.empty)(foldFunction)
        env
    }
}